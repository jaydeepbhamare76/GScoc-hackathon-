const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const pdfParse = require('pdf-parse');
const fetch = require('node-fetch'); 

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const upload = multer({ dest: 'uploads/' });

let chatHistory = [];

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'healthy', timestamp: new Date().toISOString() });
});

app.post('/api/chat', async (req, res) => {
  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  chatHistory.push({ sender: 'user', message, timestamp: new Date().toISOString() });

  if (message.toLowerCase().startsWith('find:')) {
    const query = message.substring(5).trim();

    try {
      const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}`);
      const data = await response.json();

      if (data.totalItems > 0) {
        const book = data.items[0].volumeInfo;
        const title = book.title || 'No title available';
        const authors = book.authors ? book.authors.join(', ') : 'No authors available';
        const description = book.description || 'No description available';
        const thumbnail = book.imageLinks ? book.imageLinks.thumbnail : '';
        const infoLink = book.infoLink || '';
        const googleSearch = `https://www.google.com/search?q=${encodeURIComponent(title + ' book')}`;

        const botResponse = {
          type: 'book',
          data: {
            title,
            authors,
            description,
            thumbnail,
            infoLink,
            googleSearch
          },
          timestamp: new Date().toISOString()
        };

        chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });
        res.json({ response: botResponse });
      } else {
        const botResponse = { type: 'text', data: 'No results found for your query.', timestamp: new Date().toISOString() };
        chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });
        res.json({ response: botResponse });
      }
    } catch (error) {
      console.error('Error fetching book data:', error);
      const botResponse = { type: 'text', data: 'An error occurred while fetching book data. Please try again later.', timestamp: new Date().toISOString() };
      chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });
      res.status(500).json({ response: botResponse });
    }
  } else {
    try {
      const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(message)}`);
      const data = await response.json();

      if (data.totalItems > 0) {
        const suggestions = data.items.slice(0, 3).map(item => ({
          title: item.volumeInfo.title,
          authors: item.volumeInfo.authors ? item.volumeInfo.authors.join(', ') : 'Unknown'
        }));

        const botResponse = {
          type: 'suggestions',
          data: suggestions,
          timestamp: new Date().toISOString()
        };

        chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });
        res.json({ response: botResponse });
      } else {
        const botResponse = { type: 'text', data: 'No book suggestions found. Try "find:<book name>" for a detailed search.', timestamp: new Date().toISOString() };
        chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });
        res.json({ response: botResponse });
      }
    } catch (error) {
      console.error('Error fetching suggestions:', error);
      const botResponse = { type: 'text', data: 'Error fetching suggestions. Please try again.', timestamp: new Date().toISOString() };
      chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });
      res.status(500).json({ response: botResponse });
    }
  }
});

app.get('/api/suggestions', async (req, res) => {
  const { query } = req.query;

  if (!query) {
    return res.status(400).json({ suggestions: [], error: 'Query parameter is required' });
  }

  try {
    const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}`);
    const data = await response.json();

    const suggestions = data.totalItems > 0
      ? data.items.slice(0, 5).map(item => ({
          title: item.volumeInfo.title,
          authors: item.volumeInfo.authors ? item.volumeInfo.authors.join(', ') : 'Unknown'
        }))
      : [];

    res.json({ suggestions, timestamp: new Date().toISOString() });
  } catch (error) {
    console.error('Error fetching autocomplete suggestions:', error);
    res.status(500).json({ suggestions: [], error: 'Failed to fetch suggestions' });
  }
});

app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded.' });
    }

    const filePath = req.file.path;
    const fileInfo = {
      filename: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype,
      timestamp: new Date().toISOString()
    };

    const dataBuffer = fs.readFileSync(filePath);
    const pdfData = await pdfParse(dataBuffer);

    const text = pdfData.text;
    const summary = text.slice(0, 200) + (text.length > 200 ? '...' : '');

    const botResponse = {
      type: 'text',
      data: `Summary of ${fileInfo.filename}:\n${summary}`,
      timestamp: new Date().toISOString()
    };

    fs.unlinkSync(filePath);

    chatHistory.push({ sender: 'user', message: fileInfo.filename, timestamp: new Date().toISOString() });
    chatHistory.push({ sender: 'bot', message: botResponse, timestamp: new Date().toISOString() });

    res.json({ fileInfo, botResponse });
  } catch (error) {
    console.error('Error processing PDF:', error);
    if (req.file) fs.unlinkSync(req.file.path); 
    res.status(500).json({ error: 'Error processing the PDF. Please try again.', timestamp: new Date().toISOString() });
  }
});

app.listen(PORT, () => {
  console.log(`AR Notes Buddy server running on http://localhost:${PORT}`);
});